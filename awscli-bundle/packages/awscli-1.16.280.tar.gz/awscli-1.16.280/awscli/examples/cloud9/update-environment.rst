**To change the settings of an existing AWS Cloud9 development environment**

This example changes the specified settings of the specified existing AWS Cloud9 development environment.

Command::

  aws cloud9 update-environment --environment-id 8a34f51ce1e04a08882f1e811bd706EX --name my-changed-demo-env --description "My changed demonstration development environment."

Output::

  None.