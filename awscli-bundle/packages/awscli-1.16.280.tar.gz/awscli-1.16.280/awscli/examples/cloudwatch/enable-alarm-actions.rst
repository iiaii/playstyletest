**To enable all actions for an alarm**

The following example uses the ``enable-alarm-actions`` command to enable all actions for the alarm named myalarm.::

  aws cloudwatch enable-alarm-actions --alarm-names myalarm

This command returns to the prompt if successful.

